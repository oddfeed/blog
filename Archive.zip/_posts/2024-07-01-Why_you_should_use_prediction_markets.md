# Why you should use manifold market
### What is a prediction market?
Prediction markets allow you to bet on the outcome of future events.

### Accountability
If I (an obscure) public figure make a prediction how do you know my prediction is accurate? You have to wait - but before that you also have to make a judgement call based mostly on nothing as to if my prediction _will be_ accurate, now you’re making a prediction based on if my prediction will be accurate, this is now very disconnected from the event itself, public prediction markets like manifold allow you to make your predictions in public, in a way you can be held to account; if you have and use it I can know how many predictions you’ve gotten right/wrong and I can know what area those predictions are in, some people might be really good at predicting AI events but terrible at political ones 

### Why bet?
On a prediction market you don’t just make a prediction, you also bet an amount (on some this can be real money, on manifold it isn’t) and the reason why is simple, the more confident you are in a prediction the more you should bet, but there’s a second more interesting effect which is when people are asked to wager on an event (even fictional currency) the accuracy of their predictions increases. That means if you’re trying to predict (x) forcing yourself to make a wager will actually lead to you making a better prediction in the same amount of time. 

### Rambling
To make it simple manifold is a free game to make predictions and compete with friends, I would include my referral but that would taint my motives - a lot of people are simply not aware this site exists even though it’s a lot of fun to use, in fact I literally have several accounts for different friends groups. Worst case scenario you realise you’re not good at making predictions or certain types of predictions so you improve your knowledge.

