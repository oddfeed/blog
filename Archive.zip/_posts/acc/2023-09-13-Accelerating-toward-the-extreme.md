---
tags: [acc]
---

# Accelerating toward the extreme

When you see accelerationism clearly you don't just end up with a political belief, you end up with an observation that the natural state of things seems to be that things move towards the extreme.

However, beyond its philosophical implications, accelerationism can also be seen as a broader observation about the trajectory of our society. It suggests that various aspects of our world are constantly pushing towards extremes and that this trend is becoming more pronounced with time.

This observation can be seen in various domains. In politics, for example, there seems to be an increasing polarization between different ideologies. Centrist positions are often overshadowed by more extreme right-wing or left-wing views. This shift towards the extreme can also be observed in social issues, where conversations around topics such as identity politics or climate change have become increasingly polarized.

In economics, we see a similar pattern. The gap between the rich and poor continues to widen as wealth becomes concentrated in the hands of a few individuals or corporations. The rise of tech giants like Amazon or Google exemplifies how certain companies can achieve unprecedented levels of dominance and control.

Technological advancements also contribute to this trend. The rapid development of artificial intelligence and automation threatens to disrupt traditional job markets and societal structures. This acceleration towards extreme automation could either lead to unprecedented prosperity or exacerbate existing inequalities. Moreover, our digital age has facilitated the spread of extreme ideologies through social media platforms. The echo chambers created by algorithms often reinforce existing beliefs and push individuals towards more radical positions.

Overall, accelerationism implies that our society is inherently inclined to move towards extremes due to various interconnected factors such as politics, economics, technology, and communication. While some may argue that this trajectory is concerning and calls for caution, others see it as an opportunity for transformation and the potential emergence of new paradigms.
